import React from 'react'

export const page = () => {
  return (
    <div>
        <p>Payment Success</p>

    </div>
  )
}
