"use client"
import React from "react";

const Buy = ({ makePayment }) => {
  return (
    <div>
      <button
        onClick={() => {
          makePayment({ productId: "example_ebook" });
        }}
      >
        Buy
      </button>
    </div>
  );
};

export default Buy;
